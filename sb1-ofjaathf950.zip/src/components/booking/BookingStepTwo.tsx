import React from 'react';
import { Users, Mail, Phone, User, MessageSquare } from 'lucide-react';
import FormInput from '../form/FormInput';
import Button from '../ui/Button';
import { StepTwoData } from '../../types/booking';
import LocationMap from './LocationMap';

interface BookingStepTwoProps {
  formData: StepTwoData;
  locationData: {
    pickupAddress: string;
    dropoffAddress: string;
  };
  onChange: (data: Partial<StepTwoData>) => void;
  onSubmit: () => void;
  onBack: () => void;
}

export default function BookingStepTwo({ 
  formData, 
  locationData,
  onChange, 
  onSubmit,
  onBack 
}: BookingStepTwoProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-center mb-6">Tell Us More About Your Trip</h2>

      <LocationMap
        pickupAddress={locationData.pickupAddress}
        dropoffAddress={locationData.dropoffAddress}
        className="mb-6"
      />
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <FormInput
          label="Full Name"
          name="fullName"
          type="text"
          value={formData.fullName}
          onChange={(e) => onChange({ fullName: e.target.value })}
          required
          icon={User}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormInput
            label="Number of Travelers"
            name="passengers"
            type="number"
            value={formData.passengers}
            onChange={(e) => onChange({ passengers: Number(e.target.value) })}
            required
            icon={Users}
            min={1}
          />

          <FormInput
            label="Phone Number"
            name="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => onChange({ phone: e.target.value })}
            required
            icon={Phone}
          />
        </div>

        <FormInput
          label="Email Address"
          name="email"
          type="email"
          value={formData.email}
          onChange={(e) => onChange({ email: e.target.value })}
          required
          icon={Mail}
        />

        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
            <MessageSquare size={18} />
            Special Requirements (Optional)
          </label>
          <textarea
            name="specialRequests"
            value={formData.specialRequests}
            onChange={(e) => onChange({ specialRequests: e.target.value })}
            rows={4}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Examples of special requests:
• Child seat (please specify age)
• Booster seat
• Executive/luxury vehicle
• Extra luggage space
• Meet & Greet service
• Flight monitoring
• Multiple stops
• Wheelchair accessible vehicle
• Non-smoking driver
• Specific vehicle brand preference"
          />
        </div>

        <div className="flex gap-4">
          <Button
            variant="secondary"
            onClick={onBack}
            type="button"
            className="flex-1"
          >
            ← Back
          </Button>
          <Button type="submit" className="flex-1">
            Request Booking
          </Button>
        </div>
      </form>
    </div>
  );
}