import React from 'react';
import { Calendar, MapPin, Clock } from 'lucide-react';
import AddressInput from '../form/AddressInput';
import FormInput from '../form/FormInput';
import Button from '../ui/Button';
import { StepOneData } from '../../types/booking';
import LocationMap from './LocationMap';

interface BookingStepOneProps {
  formData: StepOneData;
  onChange: (data: Partial<StepOneData>) => void;
  onNext: () => void;
}

export default function BookingStepOne({ formData, onChange, onNext }: BookingStepOneProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  return (
    <div className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-center mb-6">Book Your Private Transfer!</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <AddressInput
          label="Pick-Up Address"
          name="pickupAddress"
          value={formData.pickupAddress}
          onChange={(value) => onChange({ pickupAddress: value })}
          required
        />

        <AddressInput
          label="Drop-Off Address"
          name="dropoffAddress"
          value={formData.dropoffAddress}
          onChange={(value) => onChange({ dropoffAddress: value })}
          required
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormInput
            label="Date"
            name="date"
            type="date"
            value={formData.date}
            onChange={(e) => onChange({ date: e.target.value })}
            required
            icon={Calendar}
          />

          <FormInput
            label="Time"
            name="time"
            type="time"
            value={formData.time}
            onChange={(e) => onChange({ time: e.target.value })}
            required
            icon={Clock}
          />
        </div>

        {formData.pickupAddress && formData.dropoffAddress && (
          <LocationMap
            pickupAddress={formData.pickupAddress}
            dropoffAddress={formData.dropoffAddress}
          />
        )}

        <Button type="submit" className="w-full">
          Next Step →
        </Button>
      </form>
    </div>
  );
}