export interface StepOneData {
  pickupAddress: string;
  dropoffAddress: string;
  date: string;
  time: string;
}

export interface StepTwoData {
  fullName: string;
  passengers: number;
  phone: string;
  email: string;
  specialRequests: string;
}

export interface BookingFormData extends StepOneData, StepTwoData {}